function [ covariance ] = compute_kernel( x1, x2, lengthscale, variance )

	%% Implement covariance functon
end

